#include "prioritetine_eile.h"
#include <string.h>

prioritetine_eilep sukurti_eile()
{
    prioritetine_eilep naujas;
    naujas = malloc(sizeof(prioritetine_eile_t));
    naujas->kitas = NULL;
    naujas->duom= NULL;

    
    return naujas;
}




void trinti_eile(prioritetine_eilep head)
{ 

    if(head->kitas)
    {
        trinti_eile(head->kitas);

    }

    free(head->duom);
    free(head);
    head = NULL;
        
}

int ar_tuscias(prioritetine_eilep head)
{
    return (head->duom == NULL);
}




int iterpti_elementa(prioritetine_eilep* head, const tipas duom, int priority)
{
   
    if (ar_pilnas(*head))
    {
        return 0;
    }

    prioritetine_eilep tmphead = *head;
    tipas duomenysp = malloc(sizeof(tipas_t));
    duomenysp = memcpy(duomenysp, duom, sizeof(tipas_t));


    if (tmphead->duom == NULL)
    {
        tmphead->prioritetas = priority;
        tmphead->duom = duomenysp;
        return 1;
    }

    prioritetine_eilep naujasel = malloc(sizeof(prioritetine_eile_t));
    naujasel->duom = duomenysp;
    naujasel->prioritetas = priority;
    naujasel->kitas = NULL;
#ifdef DIDEJIMO_EILE
    if (priority >= tmphead->prioritetas)
    {
#else
    if (priority <= tmphead->prioritetas)
    {
#endif
        naujasel->kitas = tmphead;
        *head = naujasel;
        return 1;
    }

    prioritetine_eilep nextp = tmphead;

    while(nextp->kitas && nextp->kitas->prioritetas > priority)
    {
        nextp = nextp->kitas;
    }
    naujasel->kitas = nextp->kitas;
    nextp->kitas = naujasel;

    return 1;


}


tipas tikrinti_pirma(prioritetine_eilep head)
{
    if (ar_tuscias(head))
    {
        return NULL;
    }
    tipas retval = malloc(sizeof(tipas_t));
    *retval = *(head->duom) ; //memcpy(retval,head->duom,sizeof(tipas_t));
    return retval;
}

int isimti_is_eiles(prioritetine_eilep* head)
{

    if(ar_tuscias(*head))
    {
        return 0;
    }
    else if ((*head)->kitas == NULL)
    {
        free((*head)->duom);
        (*head)->duom = NULL;
        return 1;
    }
    prioritetine_eilep tmp = *head;
    *head = tmp->kitas;
    free(tmp->duom);
    free(tmp);
    return 1;
}

unsigned int elementu_kiekis(prioritetine_eilep head)
{
    if (!head)
    {
        return 0;
    }
    return 1+elementu_kiekis(head->kitas);
}

int ar_pilnas(prioritetine_eilep head)
{
    return (elementu_kiekis(head) == MAX_ELEM);
}
