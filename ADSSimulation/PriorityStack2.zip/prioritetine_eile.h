#ifndef PRIORITETINE_EILE_H
#define PRIORITETINE_EILE_H
#include <stdlib.h>
#include <limits.h>

#define MAX_ELEM UINT_MAX
#define DIDEJIMO_EILE     //iskomentuoti, norint apkeisti eiles tvarka



    typedef TYPE tipas_t;  // apibrezti tipa bei NUSTATYTI PRIES KOMPILIUOJANT!!!!

    
    typedef tipas_t* tipas;




typedef struct prioritetine_eile_t{
    int prioritetas;
    struct prioritetine_eile_t* kitas;
    tipas duom;
}prioritetine_eile_t;

typedef  prioritetine_eile_t* prioritetine_eilep;


void trinti_eile(prioritetine_eilep head); //Istrina visa eile, eiles pointeris argumentas
prioritetine_eilep sukurti_eile(); //grazina pointeri i tuscia eile
int ar_tuscias(prioritetine_eilep head); // 1 - tuscia, 0 - netuscia
int iterpti_elementa(prioritetine_eilep* head, const tipas duom, int priority); //head - pointeris i eiles head pointer'i , tipas - duomenu adresas (tipas_t *), grazina 0 jei eile pilna.
                                                                                //Duomenys yra duplikuojami i eile.

tipas tikrinti_pirma(prioritetine_eilep head); //grazina  pointeri, jei tuscia NULL;
int isimti_is_eiles(prioritetine_eilep* head); //jei 0 - eile jau tuscia
int ar_pilnas(prioritetine_eilep head); //1 - pilna eile, 0 - ne pilna
unsigned int elementu_kiekis(prioritetine_eilep head); // grazina el, kieki
#endif
