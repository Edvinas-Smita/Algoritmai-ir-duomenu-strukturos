#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "prioritetine_eile.h"







void spausdinti_eile(prioritetine_eilep head) //testavimo/ debugginimo f-ja 
{
    if(!head)
    {
        return;
    }

    printf("pri: %03d abc.a = %3d, abc.b = %.2f \tabc_adr %p \tnode_adr %p\n", head->prioritetas, head->duom->a, head->duom->b, head->duom, head);
    spausdinti_eile(head->kitas);
}

int main()
{
    abc tester;
    unsigned int i;
    int elemc= 0;

    
    prioritetine_eilep eile = sukurti_eile();

    
    tester.a = 0;
    tester.b =0;
    iterpti_elementa(&eile, &tester, 0);
    tester.a = 2;
    iterpti_elementa(&eile, &tester, -1);
    tester.a = 3;
    iterpti_elementa(&eile, &tester, 2);
    spausdinti_eile(eile);

    printf("%d\n\n", elementu_kiekis(eile));
    abc* testret = tikrinti_pirma(eile);
    printf( "%d %.2f\n\n", testret->a, testret->b);
    free( testret);
    isimti_is_eiles(&eile);
    spausdinti_eile(eile);
    isimti_is_eiles(&eile);
    isimti_is_eiles(&eile);

    for (i = 0; i < 1000; i++)
    {
        tester.a = i;
        tester.b = sqrt(i);

        if (rand()%4)
        {
            iterpti_elementa(&eile, &tester, rand()%1000);
            elemc++;
        }
        else
        {
            isimti_is_eiles(&eile);
            elemc--;
        }

        
    }
    //spausdinti_eile(eile);  
    //getchar();
    printf("\n%d %d\n",elementu_kiekis(eile),elemc);

    trinti_eile(eile);



    return 0;
}
