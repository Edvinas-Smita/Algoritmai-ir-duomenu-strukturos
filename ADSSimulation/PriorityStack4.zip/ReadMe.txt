Autorius: Darius Kurtinaitis

Prioritetines eiles implementacija c kalba.
Naudojimas:
	Sukurimas: 
		create();
	Patikrinimas, ar tuscia: 
		isEmpty(Priority_queue q);
	Didziausio prioriteto reiksmes gavimas:
		top(struct priority_queue *q, int *err);	
	Naujos reiksmes iterpimas:
		push(struct priority_queue **q, TYPE el, int priority, int *err);
	Didziausio prioriteto reiksmes istrynimas:
		pop(struct priority_queue **q, int *err);
	Prioritetiniu eiliu sujungimas i viena:
		Priority_queue join(Priority_queue q1, Priority_queue q2);
	Prioritetines eiles istrynimas:
		remove_queue(Priority_queue q, int *err);
Klaidu kodai:
	1 - klaida, operacija nepavyko del priezasciu tiksliau aprasytu header faile.
	0 - nera klaidos.
Kontaktai:
	Radus netikslumu prasome susisiekti el. pastu:
		dariuskrtn@gmail.com
