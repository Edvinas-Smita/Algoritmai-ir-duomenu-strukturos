#include <stdio.h>
#include <stdlib.h>
#include "priority_queue.h"

int main()
{
    Priority_queue q = create();

    int i, j;

    /**
    for (i=0; i<10000000; i++) {
        push(&q, 5, rand());
        push(&q, 19, rand());
        pop(&q);
        pop(&q);
    }
    return 0;
    */
    int t;
    scanf("%d", &t);
    for (i=0; i<10000; i++) {
        for (j=0; j<1000; j++) {
                int r1 = rand()%500, r2=rand()%500;
            push(&q, r1, r2, &t);
            if (t) {
                //This usually doesn't happen.
                //printf("Failed to push value '%d' to priority queue\n", r1);
            } else {
                //printf("Current top value in priority queue: %d\n", top(q));
            }
        }
        for (j=0; j<1000; j++) {
            pop(&q, &t);
            //printf("Current top value in priority queue: %d\n", top(q));
        }
    }
    if (isEmpty(q)) {
        printf("Queue is empty\n");
    } else {
        printf("Queue is not empty\n");
    }

    push(&q, 5, 5, &t);
    Priority_queue q2 = create();

    push(&q2, 7, 7, &t);
    q = join(q, q2);
    printf("Top value after joining two queues: %d\n", top(q, &t));

    return 0;
}
