#include <stdio.h>
#include <stdlib.h>
#include "priority_queue.h"

int isEmpty(struct priority_queue *q) {
    return q==NULL;
}

struct priority_queue* create() {
    return NULL;
};

/**
Pushes already created node to the tree.
*/
struct priority_queue* pushNode(struct priority_queue *q, struct priority_queue *node) {
    if (q==NULL) return node;
    if (node->priority < q->priority) {
        if (q->l==NULL) {
            q->l = node;
        } else {
            pushNode(q->l, node);
        }
    } else {
        if (q->r==NULL) {
            q->r = node;
        } else {
            pushNode(q->r, node);
        }
    }
    return q;
}

void push(struct priority_queue **q, TYPE el, int priority, int *err) {
    struct priority_queue *node = malloc(sizeof(struct priority_queue));
    if (node==NULL) {
        *err = 1;
        return;
    }
    node->val = el;
    node->priority = priority;
    node->l=node->r=NULL;
    *q = pushNode(*q, node);
    *err = 0;
}

TYPE top(struct priority_queue *q, int *err) {
    if (q==NULL) {
        *err = 1;
        return NULL;
    }
    *err = 0;
    if (q->r!=NULL) return top(q->r, err);
    return q->val;
}

void pop(struct priority_queue **q, int *err) {
    struct priority_queue *qq = *q;
    if (qq==NULL) {
        *err = 1;
        return;
    }
    if (qq->r!=NULL) {
        pop(&(qq->r), err);
    } else {
         struct priority_queue *l = qq->l;
         free(qq);
         *q = l;
    }
    *err = 0;
}

struct priority_queue* join(struct priority_queue *q1, struct priority_queue *q2) {
    if (q1==NULL) return q2;
    if (q2==NULL) return q1;

    if (q2->l!=NULL) join(q1, q2->l);
    if (q2->r!=NULL) join(q1, q2->r);

    q2->l=q2->r=NULL;
    pushNode(q1, q2);
    return q1;
};

void remove_queue(struct priority_queue *q, int *err) {
    *err = (q==NULL);
    int t;
    while (q!=NULL) pop(q, &t);
}
