#ifndef PRIORITY_QUEUE_H_INCLUDED
#define PRIORITY_QUEUE_H_INCLUDED
typedef int TYPE;

typedef struct priority_queue {
    TYPE val;
    int priority;
    struct priority_queue *l, *r;
} *Priority_queue;

//Checks if priority_queue is empty.
int isEmpty(Priority_queue q);

//Created new priority queue.
Priority_queue create();

//Returns biggest priority value from the queue or NULL if queue is empty.
//err=1 if queue is empty.
TYPE top(struct priority_queue *q, int *err);

//Pushes new value with priority to the queue.
//returns err = 1 if push fails, else err = 0
void push(struct priority_queue **q, TYPE el, int priority, int *err);

//Removes value with biggest priority from the queue.
//Returns err=1 if queue is already empty.
void pop(struct priority_queue **q, int *err);

//Joins queue q2 to q1.
Priority_queue join(Priority_queue q1, Priority_queue q2);

//clears priority queue.
//Returns err=1 if queue is already NULL.
void remove_queue(Priority_queue q, int *err);

#endif // PRIORITY_QUEUE_H_INCLUDED
