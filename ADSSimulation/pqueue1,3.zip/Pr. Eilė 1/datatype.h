#ifndef DATA_TYPE_H_INCLUDED
#define DATA_TYPE_H_INCLUDED
#endif // DATA_TYPE_H_INCLUDED

typedef int data_type;
