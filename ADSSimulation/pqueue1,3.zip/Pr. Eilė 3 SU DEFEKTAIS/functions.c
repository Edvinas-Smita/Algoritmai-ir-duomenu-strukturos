//Laurynas Motiejūnas 2gr. PS
#include <stdio.h>
#include <stdlib.h>
#include "functions.h"


Queue Create(Data newData,Data newPriority)
{
    Queue new = (Queue)malloc(sizeof(struct node)); // priskiriame vieta atmintyje
    new->data = newData;
    new->priority = newPriority;
    new->next = NULL;
    return new;
}


int Insert(Queue* start, Data newData, int newPriority)
{

    Queue newStart = (*start);
    Queue temp = Create(newData, newPriority);
    //Jeigu iterpiamas elementas turi didesni priorieta neigu virsutinis elementas
    if ((*start)->priority > newPriority)
    {
        temp->next = *start;
        (*start) = temp;
    }
    else
    {
        //Ieskom pozicijos kur iterpti
        while (newStart->next != NULL && newStart->next->priority <= newPriority)
        {
            newStart = newStart->next;
        }
        temp->next = newStart->next;
        newStart->next = temp;
        //Iterpiame i reikiama pozicija
    }
    return 1;

}

int IsEmpty(Queue* start)
{
    if((*start) == NULL) return 1;
    else return 0;
}
int DeleteQueue(Queue* start)
{
    while(!IsEmpty(start))
    {
        Remove(start);
    }
    return 1;
}
Data Remove(Queue* start)
{
    Queue temp = *start;
    if(IsEmpty(start)==0)
    {
        Data returnData;
        returnData = temp->data;
        (*start) = (*start)->next;
        free(temp);
        return returnData;
    }
}
//Grazinamas data kuris removinamas DONE
int Join(Queue* start, Queue* start2)
{
    //Vykdome cikla, kol antroji eile nera tuscia, kuris perkelia elementus ir iterpia is antros eiles i pirma
    if(IsEmpty(start)) return 0;
    while(!IsEmpty(start2))
    {
        Insert(start,(*start2)->data,(*start2)->priority);
        Remove(start2);
    }
    return 1;
}



