//Laurynas Motiejūnas 2gr. PS
#ifndef PRIORITY_QUEUE_FUNCTIONS_H
#define PRIORITY_QUEUE_FUNCTIONS_H

typedef int Data;
typedef struct node *Queue;
typedef struct node {
    Data data;
    int priority;
    struct node* next;
};


Queue Create(Data newData,Data newPriority); //sukuria nauja eile su nauja reiksme ir prioritetu
int Insert(Queue* start, Data newData, int newPriority); //ideda elementa i tinkama vieta naudojantis prioritetais. Jei pavyksta returnina 1
int IsEmpty(Queue* start);//tikrina ar eile yra tuscia ir grazina 1 jei taip
Data Remove(Queue* start);//istrina elementa su didziausiu (0) prioritetu
int Join(Queue* start, Queue* start2);//sujungia kelias eiles i viena naudojantis prioritetus. Galutine eile gaunama yra pirmoji. Pavykus grazina 1
int DeleteQueue(Queue* start);//istrina visa eile, ir grazina 1 jei pavyksta
#endif //PRIORITY_QUEUE_FUNCTIONS_H
