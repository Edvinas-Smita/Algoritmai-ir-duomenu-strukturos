//Laurynas Motiejūnas 2gr. PS
#include <stdio.h>
#include <stdlib.h>
#include "functions.h"

int main() {
    Queue queue = Create(5,1);
//    Insert(&queue, 420, 1);
//    Insert(&queue,6, 10);
//    Insert(&queue, 9, 1);
//    Insert(&queue, 49, 8);
    //DeleteQueue(&queue);

//    Queue queue2=Create (1,99);
//    Insert(&queue, 50, 8);
//    Join(&queue,&queue2);

//    Remove(&queue);
//    if(IsEmpty(&queue)) printf("Empty");
//    Remove(&queue);
//    printf("%d",a);
//    Insert(&queue, 6, 1);
//    Insert(&queue, 7, 1);
//    Insert(&queue, 8, 1);
    //Remove(&queue);

//    Insert(&queue2,69, 0);

//    Insert(&queue2, 8, 1);
//    while(!IsEmpty(&queue))
//    {
//        printf("%d ", Remove(&queue));
//    }
//    printf("\n");
//    while(!IsEmpty(&queue2))
//    {
//        printf("%d ", queue2->data);
//        Remove(&queue2);
//    }
//    Join(&queue,&queue2);
//    while(!IsEmpty(&queue))
//    {
//        printf("%d ",Remove(&queue));
//    }



//    int a = 0;
//    scanf("%d", &a);
//    for (int i = 0; i < 1000000; ++i)
//    {
//        printf("a");
//
//        for (int j = 0; j < 1000; ++j)
//        {
//
//            Insert(&queue, 5, 1);
//        }
//
//        for (int j = 0; j < 1000; ++j)
//        {
//            Remove(&queue);
//        }
//
//    }
    return 0;
}